# vertices.py
from object_library import all_vertices, Vertex
import particles as P
import couplings as C

# Ternary vertex: t~ t zeta
# Correct structure: Anti-Quark + Quark + Scalar
# Color: Identity(1,2) connects color of particle 1 (t~) and particle 2 (t) -> Singlet
for i in range(3):
    z_part = [P.Z1, P.Z2, P.Z3][i]
    
    # Vertex name must be unique
    vertex = Vertex(name = f'TERNARY_{i}',
                    particles = [P.t.anti(), P.t, z_part], # FIXED: added .anti()
                    color = ['Identity(1,2)'],
                    lorentz = ['FFS'],
                    couplings = {(0,0): C.c_tern})
    all_vertices.add(vertex)