# lorentz.py
from object_library import all_lorentz, Lorentz

# Scalar coupling to fermions: (1-g5)/2 + (1+g5)/2 = Identity
# This represents a pure scalar interaction (L+R)
FFS = Lorentz(name = 'FFS',
              spins = [ 2, 2, 1 ],
              structure = 'ProjM(2,1) + ProjP(2,1)')