# particles.py
from object_library import all_particles, Particle
import parameters as Param

# Top quark
t = Particle(pdg_code = 6,
             name = 't',
             antiname = 't~',
             spin = 2,
             color = 3,
             mass = 'MT',
             width = 'WT',
             texname = 't',
             antitexname = '\\bar{t}',
             charge = 2./3)

# Vacuum scalar triplet (Grade-2)
# Defined as self-conjugate (real scalars) for simplicity in phenomenology
Z1 = Particle(pdg_code = 9000001,
              name = 'z1',
              antiname = 'z1',
              spin = 1,
              color = 1,
              mass = 'Mzeta',
              width = 'WZETA',
              texname = '\\zeta^1',
              antitexname = '\\zeta^1',
              charge = 0.0)

Z2 = Z1.clone()
Z2.set('name', 'z2')
Z2.set('antiname', 'z2')
Z2.set('texname', '\\zeta^2')
Z2.set('pdg_code', 9000002)

Z3 = Z1.clone()
Z3.set('name', 'z3')
Z3.set('antiname', 'z3')
Z3.set('texname', '\\zeta^3')
Z3.set('pdg_code', 9000003)