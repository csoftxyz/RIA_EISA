# parameters.py
from object_library import all_parameters, Parameter

# Standard Model / Physics parameters
v = Parameter(name = 'v',
              nature = 'external',
              type = 'real',
              value = 246.22,
              texname = 'v')

# Top properties
MT = Parameter(name = 'MT',
               nature = 'external',
               type = 'real',
               value = 173.0,
               texname = 'M_t')

WT = Parameter(name = 'WT',
               nature = 'external',
               type = 'real',
               value = 1.5,
               texname = '\\Gamma_t')

# Z3 Vacuum parameters
# Fixed algebraically as per paper
lam_tern = Parameter(name = 'lam_tern',
                     nature = 'external',
                     type = 'real',
                     value = 1.0,
                     texname = '\\lambda_3')

Mzeta = Parameter(name = 'Mzeta',
                  nature = 'external',
                  type = 'real',
                  value = 1800.0,
                  texname = 'M_{\\zeta}')

# Moved WZETA here to ensure visibility
WZETA = Parameter(name='WZETA',
                  nature='external',
                  type='real',
                  value=10.0,
                  texname='\\Gamma_{\\zeta}')