# couplings.py
from object_library import all_couplings, Coupling

# Setting order to QED=1 or defining a new order 'NP' is safer for MG5 filtering
c_tern = Coupling(name = 'lam_tern',
                  value = 'lam_tern',
                  order = {'QED':1})